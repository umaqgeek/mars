<!-- Start of footer.php -->
<script src="<?php echo base_url('assets/js/bootstrap.js') ?>"></script>
<script src="<?php echo base_url('assets/js/bootigniter.js') ?>"></script>
</body>
</html>
<!-- / footer.php -->