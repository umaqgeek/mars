<!-- Start of footer.php -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html" charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="description" content="Tuffah, Informatics">
    <meta name="author" content="Bilal">
    <!-- batas -->
    <title><?=$this->config->item('system_name')?></title>
    <script src="<?php echo base_url('assets/js/jquery-1.11.1.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.dataTables.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/dataTables.jqueryui.js') ?>"></script>

    <link href="<?php echo base_url('assets/css/bootstrap.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/bootigniter.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/dashboard.css') ?>" rel="stylesheet">
      <link href="<?php echo base_url('assets/css/jquery-ui.css') ?>" rel="stylesheet">
            <link href="<?php echo base_url('assets/css/dataTables.jqueryui.css') ?>" rel="stylesheet">
    <!--[if lt IE 9]>
    <![endif]-->
  </head>
  <body>
    <!-- / header.php -->