<!-- Start of footer.php -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html" charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="description" content="Tuffah, Informatics">
    <meta name="author" content="Bilal">
    <!-- batas -->
    <title><?=$this->config->item('system_name')?></title>
    <link href="<?php echo base_url('assets/css/bootstrap.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/bootigniter.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/dashboard.css') ?>" rel="stylesheet">
    <!--[if lt IE 9]>
    <![endif]-->
  </head>
  <body>
    <!-- / header.php -->