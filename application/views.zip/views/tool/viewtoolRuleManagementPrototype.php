 <div class="container-fluid">
      <div class="row">
        
        <?=(!empty($sidebar))?$sidebar:""?>


        <div class="col-sm-5 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Structure Number</h1>
           
           <div class="row">
            <div class="col-sm-5 col-sm-offset-3">
          haha
        </div>
      </div>

      </div><!--end row-->

    </div>